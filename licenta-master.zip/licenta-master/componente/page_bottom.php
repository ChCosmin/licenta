    </tr>
  </table>
  <p class="copyright"><a href="http://www.vogelburda.ro">&copy; Vogel Burda Communications</a></p>
</body>
</html>